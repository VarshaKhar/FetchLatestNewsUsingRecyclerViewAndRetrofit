package com.example.lenovo.usingretrofitrecyclerviewnews.Tool;

/**
 * Created by varsha on 9/30/2017.
 */

public class API {
    public static String URL = "https://newsapi.org/";
}
