package com.example.lenovo.usingretrofitrecyclerviewnews.view;
/**
 * Created by varsha on 9/30/2017.
 */
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;

import com.example.lenovo.usingretrofitrecyclerviewnews.Adapter.NewsAdapter;
import com.example.lenovo.usingretrofitrecyclerviewnews.Models.ListItem;
import com.example.lenovo.usingretrofitrecyclerviewnews.Models.NewsResponse;
import com.example.lenovo.usingretrofitrecyclerviewnews.Networks.Client;
import com.example.lenovo.usingretrofitrecyclerviewnews.Networks.Method;
import com.example.lenovo.usingretrofitrecyclerviewnews.R;
import com.example.lenovo.usingretrofitrecyclerviewnews.Tool.API;

import java.util.ArrayList;
import java.util.Arrays;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private ArrayList<ListItem> data;
    private NewsAdapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getNews();
        recyclerView = (RecyclerView)findViewById(R.id.recycler_view);
       RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(layoutManager);
    }
    private void getNews() {

        Client.getClient(API.URL).create(Method.class).newsList
                ("business-insider","top","40f4392f2c6b4ecf9c2d7caf6a164432").enqueue(new Callback<NewsResponse>() {
            @Override
            public void onResponse(Call<NewsResponse> call, Response<NewsResponse> response) {
                NewsResponse newsResponse = response.body();
                data = new ArrayList<>(newsResponse.getArticles());
                adapter = new NewsAdapter(data);
                recyclerView.setAdapter(adapter);

            }

            @Override
            public void onFailure(Call<NewsResponse> call, Throwable t) {
                Log.d("Error", t.getMessage());
            }
        });
    }
}
