package com.example.lenovo.usingretrofitrecyclerviewnews.Adapter;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.lenovo.usingretrofitrecyclerviewnews.Models.ListItem;
import com.example.lenovo.usingretrofitrecyclerviewnews.R;

import java.util.ArrayList;

/**
 * Created by varsha on 30-09-2017.
 */
public class NewsAdapter extends RecyclerView.Adapter<NewsAdapter.ViewHolder> {
    private ArrayList<ListItem> newsItems;

    public NewsAdapter(ArrayList<ListItem> newsItems) {
        this.newsItems = newsItems;
    }

    @Override
    public NewsAdapter.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.recycler_view_items, viewGroup, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(NewsAdapter.ViewHolder viewHolder, int i) {

        viewHolder.txtTitle.setText("TITLE:-" + newsItems.get(i).getTitle());
        viewHolder.txtDescription.setText("DESCRIPTION:-" +newsItems.get(i).getDescription());
    }

    @Override
    public int getItemCount() {
        return newsItems.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        private TextView txtTitle,txtDescription;
        public ViewHolder(View view) {
            super(view);

            txtTitle = (TextView)view.findViewById(R.id.txtTitle);
            txtDescription = (TextView)view.findViewById(R.id.txtDescription);

        }
    }

}
