package com.example.lenovo.usingretrofitrecyclerviewnews.Networks;


import com.example.lenovo.usingretrofitrecyclerviewnews.Models.NewsResponse;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

/**
 * Created by varsha on 9/30/2017.
 */

public interface Method {
    @GET("v1/articles")
    Call<NewsResponse> newsList
            (@Query("source") String source,
             @Query("sortBy") String sortBy,
             @Query("apiKey") String apiKey);
}
